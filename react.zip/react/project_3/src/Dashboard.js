import SideBar from "./Components/SideBar";
import TopBar from "./Components/TopBar";
import { Outlet } from "react-router-dom";

export default function Dashboard() {
  return (
    <div style={{ flexWrap: "wrap" }}>
      <div>
        <TopBar />
        <div style={{ display: "flex"}}>
          <div style={{ width: "20%" }}>
            <SideBar />
          </div>
          <Outlet />
        </div>
      </div>
    </div>
  );
}
