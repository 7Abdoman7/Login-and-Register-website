import Header from "./Components/Header";

export default function Home() {
  return (
    <div>
      <Header />

      <div
        style={{
          textAlign: "center",
          justifyContent: "center",
          display: "flex",
        }}
      >
        <h1
          style={{
            color: "#86b7fe",
            fontFamily: "sans-serif",
            marginTop: "200px",
            fontSize: "72px",
            textShadow: "0 0 5px #86b7fe",
          }}
        >
          This is a Home Page
        </h1>
      </div>
    </div>
  );
}
