import SignUp from "./SignUp";
import Login from "./Login";
import { Route, Routes } from "react-router-dom";
import Home from "./Home";
import Dashboard from "./Dashboard";
import Users from "./Users";
import UpdateUser from "./UpdateUser";

export default function App() {
  return (
    <div style={{ flexWrap: "wrap" }}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Register" element={<SignUp />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/Home" element={<Home />} />
        <Route path="/Dashboard" element={<Dashboard />}>
          <Route path="Users" element={<Users />} />
          <Route path="Users/:id" element={<UpdateUser />} />
        </Route>
      </Routes>
    </div>
  );
}
