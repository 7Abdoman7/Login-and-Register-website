import {Link} from "react-router-dom";
export default function SideBar() {

    return (
        <div className="SideBar">
            <Link to="/Dashboard/Users" className="item-Link">Users</Link>
            <br />
            <Link to="/Dashboard/Products" className="item-Link">Products</Link>
        </div>
    );
}