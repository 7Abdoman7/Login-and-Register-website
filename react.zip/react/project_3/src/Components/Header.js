import { Link } from "react-router-dom";

export default function Header() {
  function handleLogOut() {
    window.localStorage.removeItem('email');
    window.location.pathname = "/Home";
  }

  return (
    <div className="container-nav">
      <nav className="nav">
        <Link to="/home" className="register-nav">
          Home
        </Link>
        <Link to="/about" className="register-nav">
          About
        </Link>
        {!window.localStorage.getItem("email") ? (
          <>
            <Link to="/register" className="register-nav">
              Register
            </Link>
            <Link to="/login" className="register-nav">
              Login
            </Link>
          </>
        ) : (
          <div className="register-nav" on onClick={handleLogOut}>Log Out</div>
        )}
      </nav>
    </div>
  );
}
