import { useState } from "react";
import axios from "axios";
import "./style.css";
import Header from "./Components/Header";

export default function SignUp() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [emailError, setEmailError] = useState("");
  const [accept, setAccept] = useState("");

  async function Submit(e) {
    e.preventDefault();
    setAccept(true);
    try {
      let res = await axios.post("http://127.0.0.1:8000/api/login", {
        email: email,
        password: password,
      });
      if (res.status === 200) {
        window.localStorage.setItem("email", email);
        window.location.pathname = "/Home";
      }
    } catch (err) {
      setEmailError(err.response.status);
    }
  }

  return (
    <div>
      <Header />

      <div className="parent">
        <div className="register">
          <form action="" onSubmit={Submit}>
            <label htmlFor="email">E-mail:</label>
            <input
              id="email"
              type="email"
              placeholder="E-mail..."
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            {email === "" && accept && (
              <p className="error">Email Field is Empty</p>
            )}

            <label htmlFor="password">Password:</label>
            <input
              id="password"
              type="password"
              placeholder="Password..."
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            {password === "" && accept && (
              <p className="error">Password Field is Empty</p>
            )}

            <div className="div">
              <button type="submit">Login</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
