import { useState } from "react";
import axios from "axios";
import "./style.css";
import Header from "./Components/Header";

export default function SignUp() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [repeat, setRepeat] = useState("");

  const [accept, setAccept] = useState(false);
  const [email_err, setEmail_err] = useState();

  async function Submit(e) {
    e.preventDefault();
    setAccept(true);

    let flag = false;

    if (name === "" || password.length < 8 || repeat !== password) {
      flag = false;
    } else {
      flag = true;
    }

    try {
      if (flag === true) {
        let res = await axios.post("http://127.0.0.1:8000/api/register", {
          name: name,
          email: email,
          password: password,
          password_confirmation: repeat,
        });
        if (res.status === 200) {
          window.localStorage.setItem("email", email);
          window.location.pathname = "/Home";
        }
      }
    } catch (err) {
      setEmail_err(err.response.status);
    }
  }

  return (
    <div>
      <Header />
      <div className="parent">
        <div className="register">
          <form action="" onSubmit={Submit}>
            <label htmlFor="name">Name:</label>
            <input
              id="name"
              type="text"
              placeholder="Name..."
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            {name === "" && accept && (
              <p className="error">Username is Required</p>
            )}

            <label htmlFor="email">E-mail:</label>
            <input
              id="email"
              type="email"
              placeholder="E-mail..."
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            {email_err === 422 && accept && (
              <p className="error">E-mail is already been taken</p>
            )}

            <label htmlFor="password">Password:</label>
            <input
              id="password"
              type="password"
              placeholder="Password..."
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            {password.length < 8 && accept && (
              <p className="error">Password must be more than 8 Char</p>
            )}

            <label htmlFor="repeat">Repeat Password:</label>
            <input
              id="repeat"
              type="password"
              placeholder="Repeat Password..."
              value={repeat}
              onChange={(e) => setRepeat(e.target.value)}
            />

            {repeat !== password && accept && (
              <p className="error">Password does not match</p>
            )}

            <div className="div">
              <button type="submit">Register</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
